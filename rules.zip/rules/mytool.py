import os
import glob

def export_yar_contents_to_file():
    # Define the output file path
    output_file_path = 'borrow.yara'
    
    # Open the output file in write mode
    with open(output_file_path, 'w') as output_file:
        # Use glob to find all .yar files in the current directory
        yar_files = glob.glob('*.yar')
        
        # Iterate over the list of .yar file paths
        for file_path in yar_files:
            # Open each .yar file in read mode
            with open(file_path, 'r') as file:
                # Read the content of the file
                content = file.read()
                
                # Write the content to the output experienced file, adding a newline for separation
                output_file.write(content + '\n')

# Execute the function
if __name__ == "__main__":
    export_yar_contents_to_file()
